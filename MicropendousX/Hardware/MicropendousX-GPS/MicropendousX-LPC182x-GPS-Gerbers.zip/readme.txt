File Format: Gerber RS-274-X
Plot Origin: Absolute

	MicropendousX-LPC182x-GPS-SilkS_Front.gto	: Top/Front Layer Silkscreen
	MicropendousX-LPC182x-GPS-Mask_Front.gts	: Top/Front Layer Solder Mask
	MicropendousX-LPC182x-GPS-Front.gtl		: Top/Front Copper Layer
	MicropendousX-LPC182x-GPS-Inner1.gbr		: Inner1 Copper Layer (closest to Top)
	MicropendousX-LPC182x-GPS-Inner2.gbr		: Inner2 Copper Layer (closest to Bottom)
	MicropendousX-LPC182x-GPS-Back.gbl		: Bottom/Back Copper Layer
	MicropendousX-LPC182x-GPS-Mask_Back.gbs		: Bottom/Back Layer Solder Mask
	MicropendousX-LPC182x-GPS-SilkS_Back.gto	: Bottom/Back Layer Silkscreen

	MicropendousX-LPC182x-GPS-PCB_Edges.oln		: PCB Edge Outline

Drill File: MicropendousX-LPC182x-GPS.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.4
	Mode (Drill Origin) : Absolute
	Zero Supression : None (Keep Zeros)
	Type : ASCII
	Drill Holes (Pads and Vias): 360
	Notes:	- Minimal Header
		- No axis mirroring and only standard vias
		- All holes are plated
